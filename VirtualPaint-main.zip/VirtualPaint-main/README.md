1. install all prerequirest from "requirements.txt"
2. now open terminal goto file location and run VertualPaint.py
3. remember index finger for draw and (index + middle) fingers for selection.
4. press small x for exit. 